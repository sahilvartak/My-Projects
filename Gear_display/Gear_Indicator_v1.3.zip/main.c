//------------------------------------------
//
// Motorcycle Gear Indicator Source v1.3        
//                         
// V.K. Papanikolaou (c)2010  
//
// Created      : 8/4/2010
// Last Updated : 12/8/2010
//
//------------------------------------------

#include <avr/io.h>     
#include <util/delay.h>
#include <avr/eeprom.h>

#define RESET_BIT PB0
#define CLOCK_BIT PB1
#define NEUTRAL_BIT PB2
#define UP_BIT PB3
#define DOWN_BIT PB4
#define RESET_DDR DDB0
#define CLOCK_DDR DDB1
#define DEBOUNCE_TIME 50
#define LOCK_TIME 250
#define TOP_GEAR 5

uint8_t Gear;

void ShowDigit(uint8_t Digit)
{
    uint8_t i;
	
	PORTB |= (1 << RESET_BIT);       // RESET pin high
    PORTB &= ~(1 << RESET_BIT);      // RESET pin low
	
    for (i = 0; i < Digit; i++) 
    {
	    PORTB |= (1 << CLOCK_BIT);   // CLOCK pin high
        PORTB &= ~(1 << CLOCK_BIT);  // CLOCK pin low 
    }
}

void Init()
{
    uint8_t i;
	
    PORTB |= 1 << NEUTRAL_BIT;   // NEUTRAL pin enable pull-up 
	PORTB |= 1 << UP_BIT;        // UP pin enable pull-up
	PORTB |= 1 << DOWN_BIT;      // DOWN pin enable pull-up
	
    DDRB |= 1 << RESET_DDR;      // RESET pin as output 
	DDRB |= 1 << CLOCK_DDR;      // CLOCK pin as output 
	
	PORTB &= ~(1 << RESET_BIT);  // RESET pin low
	
	// Self test effect
	
	ShowDigit(0);
	_delay_ms(500);
	
	for (i = 1; i < 10; i++)
	{
	    ShowDigit(i);
		_delay_ms(100);
	}
	
	ShowDigit(0);
	_delay_ms(500);
	
    Gear = eeprom_read_byte((uint8_t*)0);  // Read initial value from EEPROM
	ShowDigit(Gear);                       // Show initial value
}

int Released(uint8_t Bit)
{
    if (bit_is_clear(PINB,Bit))
	{
	    _delay_ms(DEBOUNCE_TIME);
		if (bit_is_set(PINB,Bit)) return 1;
	}
	
	return 0;
}

int main(void)
{
    Init();
	
	while(1)
    {
		if (Released(UP_BIT))
        {
		    if ((Gear > 0) && (Gear < TOP_GEAR)) Gear++;
     		if (Gear == 0) Gear = 2;
			if (bit_is_clear(PINB,NEUTRAL_BIT)) Gear = 0;
			
			eeprom_write_byte((uint8_t*)0,Gear);
			ShowDigit(Gear);
			_delay_ms(LOCK_TIME);
		}
		
		if (Released(DOWN_BIT))
		{
            if (Gear > 1) Gear--;
			if (Gear == 0) Gear = 1;
			if (bit_is_clear(PINB,NEUTRAL_BIT)) Gear = 0;
			
			eeprom_write_byte((uint8_t*)0,Gear);
			ShowDigit(Gear);
			_delay_ms(LOCK_TIME);
		}  
	}
} 
